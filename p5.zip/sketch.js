let jogador;

let inimigos = [];

let tiros = [];

let pontos = 0;

function setup() {

  createCanvas(800, 600);

  jogador = {

    x: width / 2,

    y: height - 50,

    velocidade: 5

  };

  for (let i = 0; i < 10; i++) {

    inimigos.push({

      x: random(width),

      y: random(-100, 0),

      velocidade: random(2, 5)

    });

  }

}

function draw() {

  background(220);

  

  // Desenhar jogador

  fill(0);

  rect(jogador.x, jogador.y, 50, 50);

  

  // Mover jogador

  if (keyIsDown(LEFT_ARROW)) {

    jogador.x -= jogador.velocidade;

  }

  if (keyIsDown(RIGHT_ARROW)) {

    jogador.x += jogador.velocidade;

  }

  

  // Desenhar inimigos

  for (let i = inimigos.length - 1; i >= 0; i--) {

    fill(255, 0, 0);

    rect(inimigos[i].x, inimigos[i].y, 30, 30);

    inimigos[i].y += inimigos[i].velocidade;

    

    // Verificar colisão com jogador

    if (inimigos[i].y > height) {

      inimigos.splice(i, 1);

      pontos -= 10;

    }

  }

  

  // Desenhar tiros

  for (let i = tiros.length - 1; i >= 0; i--) {

    fill(0, 0, 255);

    rect(tiros[i].x, tiros[i].y, 10, 20);

    tiros[i].y -= 10;

    

    // Verificar colisão com inimigos

    for (let j = inimigos.length - 1; j >= 0; j--) {

      if (dist(tiros[i].x, tiros[i].y, inimigos[j].x, inimigos[j].y) < 20) {

        inimigos.splice(j, 1);

        tiros.splice(i, 1);

        pontos += 10;

      }

    }

    

    // Remover tiro se sair da tela

    if (tiros[i].y < 0) {

      tiros.splice(i, 1);

    }

  }

  

  // Adicionar novos inimigos

  if (frameCount % 60 === 0) {

    inimigos.push({

      x: random(width),

      y: -100,

      velocidade: random(2, 5)

    });

  }

  

  // Mostrar pontos

  fill(0);

  textSize(32);

  text(`Pontos: ${pontos}`, 20, 40);

}

function keyPressed() {

  if (key === ' ') {

    tiros.push({

      x: jogador.x + 25,

      y: jogador.y

    });

  }

}